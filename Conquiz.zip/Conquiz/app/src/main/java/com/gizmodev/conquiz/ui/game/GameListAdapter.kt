package com.gizmodev.conquiz.ui.game

import android.databinding.DataBindingUtil
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.ViewGroup
import com.gizmodev.conquiz.R
import com.gizmodev.conquiz.databinding.ItemGameBinding
import com.gizmodev.conquiz.model.Game


class GameListAdapter: RecyclerView.Adapter<GameListAdapter.ViewHolder>() {
    private lateinit var gameList:List<Game>

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): GameListAdapter.ViewHolder {
        val binding: ItemGameBinding = DataBindingUtil.inflate(LayoutInflater.from(parent.context), R.layout.item_game, parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: GameListAdapter.ViewHolder, position: Int) {
        holder.bind(gameList[position])
    }

    override fun getItemCount(): Int {
        return if(::gameList.isInitialized) gameList.size else 0
    }

    fun updateGameList(gameList:List<Game>){
        this.gameList = gameList
        notifyDataSetChanged()
    }

    class ViewHolder(private val binding: ItemGameBinding):RecyclerView.ViewHolder(binding.root){
        private val viewModel = GameViewModel()

        fun bind(post:Game){
            viewModel.bind(post)
            binding.viewModel = viewModel
        }
    }
}