package com.gizmodev.conquiz.injection.component

import android.support.v4.app.ListFragment
import dagger.Module
import dagger.android.ContributesAndroidInjector


@Module
abstract class MainFragmentBindingModule {

    @ContributesAndroidInjector
    internal abstract fun provideListFragment(): ListFragment

    @ContributesAndroidInjector
    internal abstract fun provideDetailsFragment(): DetailsFragment
}