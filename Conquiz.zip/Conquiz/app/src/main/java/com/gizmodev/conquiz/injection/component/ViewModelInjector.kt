package com.gizmodev.conquiz.injection.component

import com.gizmodev.conquiz.injection.module.NetworkModule
import com.gizmodev.conquiz.viewmodel.GameListViewModel
import dagger.Component
import javax.inject.Singleton

@Singleton
@Component(modules = [(NetworkModule::class)])
interface ViewModelInjector {
    /**
     * Injects required dependencies into the specified PostListViewModel.
     * @param gameListViewModel GameListViewModel in which to inject the dependencies
     */
    fun inject(gameListViewModel: GameListViewModel)

    @Component.Builder
    interface Builder {
        fun build(): ViewModelInjector

        fun networkModule(networkModule: NetworkModule): Builder
    }
}