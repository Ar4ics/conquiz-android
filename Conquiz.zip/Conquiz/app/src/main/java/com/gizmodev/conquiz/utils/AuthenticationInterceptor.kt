package com.gizmodev.conquiz.utils

import okhttp3.Interceptor
import okhttp3.Response
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class AuthenticationInterceptor @Inject constructor() : Interceptor {

    var token: String? = null

    override fun intercept(chain: Interceptor.Chain): Response {
        val original = chain.request()
        val builder = original.newBuilder()
        if (token != null) {
            builder.addHeader("Authorization", "Bearer $token")
        }
        val request = builder.build()
        return chain.proceed(request)
    }
}