package com.gizmodev.conquiz.viewmodel

import android.arch.lifecycle.ViewModel
import com.gizmodev.conquiz.injection.component.DaggerViewModelInjector
import com.gizmodev.conquiz.injection.component.ViewModelInjector
import com.gizmodev.conquiz.injection.module.NetworkModule

abstract class BaseViewModel:ViewModel(){
    private val injector: ViewModelInjector = DaggerViewModelInjector
        .builder()
        .networkModule(NetworkModule)
        .build()

    init {
        inject()
    }

    /**
     * Injects the required dependencies
     */
    private fun inject() {
        when (this) {
            is GameListViewModel -> injector.inject(this)
        }
    }
}