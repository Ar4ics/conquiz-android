package com.gizmodev.conquiz.ui.game

import android.arch.lifecycle.MutableLiveData
import com.gizmodev.conquiz.model.Game
import com.gizmodev.conquiz.viewmodel.BaseViewModel

class GameViewModel: BaseViewModel() {
    private val gameTitle = MutableLiveData<String>()
    private val gameCountX = MutableLiveData<Int>()
    private val gameCountY = MutableLiveData<Int>()

    fun bind(game: Game){
        gameTitle.value = game.title
        gameCountX.value = game.count_x
        gameCountY.value = game.count_y
    }

    fun getGameTitle():MutableLiveData<String>{
        return gameTitle
    }

    fun getGameCountX():MutableLiveData<Int>{
        return gameCountX
    }

    fun getGameCountY():MutableLiveData<Int>{
        return gameCountY
    }
}