package com.gizmodev.conquiz.network

import com.gizmodev.conquiz.model.Game
import io.reactivex.Observable
import retrofit2.http.GET

interface GameApi {
    @GET("/games")
    fun getGames(): Observable<List<Game>>
}