package com.gizmodev.conquiz.viewmodel

import android.arch.lifecycle.MutableLiveData
import android.view.View
import com.gizmodev.conquiz.R
import com.gizmodev.conquiz.model.Game
import com.gizmodev.conquiz.network.GameApi
import com.gizmodev.conquiz.ui.game.GameListAdapter
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.disposables.Disposable
import io.reactivex.schedulers.Schedulers
import javax.inject.Inject

class GameListViewModel:BaseViewModel(){
    @Inject
    lateinit var gameApi: GameApi

    private lateinit var subscription: Disposable
    val loadingVisibility: MutableLiveData<Int> = MutableLiveData()
    val errorMessage:MutableLiveData<Int> = MutableLiveData()
    val errorClickListener = View.OnClickListener { loadGames() }
    val gameListAdapter = GameListAdapter()

    init{
        loadGames()
    }

    private fun loadGames(){
        subscription = gameApi.getGames()
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .doOnSubscribe { onRetrieveGameListStart() }
            .doOnTerminate { onRetrieveGameListFinish() }
            .subscribe(
                { result -> onRetrievePostListSuccess(result) },
                { onRetrieveGameListError() }
            )
    }

    private fun onRetrieveGameListStart(){
        loadingVisibility.value = View.VISIBLE
        errorMessage.value = null

    }

    private fun onRetrieveGameListFinish(){
        loadingVisibility.value = View.GONE
    }

    private fun onRetrievePostListSuccess(gameList:List<Game>){
        gameListAdapter.updateGameList(gameList)
    }

    private fun onRetrieveGameListError(){
        errorMessage.value = R.string.game_error
    }

    override fun onCleared() {
        super.onCleared()
        subscription.dispose()
    }
}