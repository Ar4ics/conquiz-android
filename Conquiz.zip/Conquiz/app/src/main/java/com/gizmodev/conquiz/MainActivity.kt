package com.gizmodev.conquiz

import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.util.Log
import android.view.View
import com.gizmodev.conquiz.utils.Constants.GOOGLE_SIGN_IN
import com.gizmodev.conquiz.utils.Constants.SHARED_PREF
import com.gizmodev.conquiz.utils.Constants.TOKEN
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInAccount
import com.google.android.gms.auth.api.signin.GoogleSignInClient
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.SignInButton
import com.google.android.gms.common.api.ApiException
import com.google.android.gms.tasks.Task

class MainActivity : AppCompatActivity(), View.OnClickListener {
    override fun onClick(v: View?) {
        when (v?.id) {
            R.id.sign_in_button -> signIn()
        }
    }

    private lateinit var mGoogleSignInClient : GoogleSignInClient
    private lateinit var mSharedPref : SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        mSharedPref = getSharedPreferences(SHARED_PREF, MODE_PRIVATE)

        val gso = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestServerAuthCode(resources.getString(R.string.google_client_id))
            .build()

        mGoogleSignInClient = GoogleSignIn.getClient(this, gso);
        val signInButton = findViewById<SignInButton>(R.id.sign_in_button)
        signInButton.setSize(SignInButton.SIZE_STANDARD)
        signInButton.setOnClickListener(this)
    }

    private fun signIn() {
        val signInIntent = mGoogleSignInClient.signInIntent
        startActivityForResult(signInIntent, RC_GET_AUTH_CODE)
    }

    override fun onStart() {
        super.onStart()
        // Check for existing Google Sign In account, if the user is already signed in
        // the GoogleSignInAccount will be non-null.
        if (mSharedPref.contains(TOKEN)) {
            val token = mSharedPref.getString(TOKEN, "");
            if (token != null && token.isNotBlank()) {

            }
        }
    }

    private fun updateUI(account: GoogleSignInAccount?) {
        if (account != null) {
            try {
                Log.d(GOOGLE_SIGN_IN, "id=" + account.id)
                Log.d(GOOGLE_SIGN_IN, "isExpired=" + account.isExpired)
                Log.d(GOOGLE_SIGN_IN, "serverAuthCode=" + account.serverAuthCode)
                val authCode = account.serverAuthCode
                authenticate(authCode!!)
            } catch (e: Exception) {
                Log.e(GOOGLE_SIGN_IN, e.localizedMessage)
            }
        }
    }

    private fun authenticate(googleAuthCode: String) {

//        val service =  provideLoginService(provideRetrofit());
//        service.getToken(googleAuthCode).enqueue(object : Callback<Any> {
//            override fun onResponse(call: Call<Any>, response: Response<Any>) {
//                val headers = response.headers()
//                val token = headers.get("Authorization")
//                Log.d(GOOGLE_SIGN_IN, "token = $token")
//                mSharedPref.edit().putString(TOKEN, token).apply()
//            }
//
//            override fun onFailure(call: Call<Any>, t: Throwable) {
//                Log.d(GOOGLE_SIGN_IN, "error = ${t.localizedMessage}")
//                mSharedPref.edit().remove(TOKEN).apply()
//            }
//        });

    }

    public override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        // Result returned from launching the Intent from GoogleSignInClient.getSignInIntent(...);
        if (requestCode == RC_GET_AUTH_CODE) {
            // The Task returned from this call is always completed, no need to attach
            // a listener.
            val task = GoogleSignIn.getSignedInAccountFromIntent(data)
            handleSignInResult(task)
        }
    }

    private fun handleSignInResult(completedTask: Task<GoogleSignInAccount>) {
        try {
            val account = completedTask.getResult(ApiException::class.java)

            // Signed in successfully, show authenticated UI.
            updateUI(account)
        } catch (e: ApiException) {
            // The ApiException status code indicates the detailed failure reason.
            // Please refer to the GoogleSignInStatusCodes class reference for more information.
            Log.d(GOOGLE_SIGN_IN, "signInResult:failed code = " + e.localizedMessage)
            updateUI(null)
        }

    }

    companion object {
        const val RC_GET_AUTH_CODE = 1
    }
}
