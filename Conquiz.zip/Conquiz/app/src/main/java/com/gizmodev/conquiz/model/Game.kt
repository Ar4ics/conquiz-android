package com.gizmodev.conquiz.model

data class Game(val id: Int, val title: String, val count_x: Int, val count_y: Int)
