package com.gizmodev.conquiz.injection.component

import com.gizmodev.conquiz.MainActivity
import dagger.Module
import dagger.android.ContributesAndroidInjector


@Module
abstract class ActivityBindingModule {

    @ContributesAndroidInjector(modules = arrayOf(MainFragmentBindingModule::class))
    internal abstract fun bindMainActivity(): MainActivity
}