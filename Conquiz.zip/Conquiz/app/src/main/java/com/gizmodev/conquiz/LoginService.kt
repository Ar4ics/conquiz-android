package com.gizmodev.conquiz

import retrofit2.Call
import retrofit2.http.Field
import retrofit2.http.FormUrlEncoded
import retrofit2.http.POST

interface LoginService {
    @FormUrlEncoded
    @POST("auth/google")
    fun getToken(
        @Field("code") code: String
    ) : Call<Any>
}